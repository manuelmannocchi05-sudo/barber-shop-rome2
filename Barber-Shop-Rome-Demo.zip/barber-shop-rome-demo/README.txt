BARBER SHOP ROME — DEMO
Apri index.html nel browser.
La demo è pensata per essere mostrata ai primi clienti e poi personalizzata sostituendo prezzi, foto, indirizzo, telefono, orari e recensioni.
